import React,{ Component } from 'react'
import { browserHistory } from 'react-router'

class AddForm extends Component {
  constructor(){
    super();
    this.state = {
      value:''
    }
    this.onChange = this.onChange.bind(this)
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  onChange(event){
    this.setState({
      value: event.target.value,
    })
  }

  handleSubmit(){
    this.props.actions.addDetails(this.state.value);
    browserHistory.push('/')
  }

  render() {
    return (
      <form>
        <label>
          Name:
          <input type="text" value={this.state.value} onChange={this.onChange} />
        </label>
        <input type="button" value="Submit" onClick={this.handleSubmit} />
      </form>
    );
  }
}

export default AddForm
