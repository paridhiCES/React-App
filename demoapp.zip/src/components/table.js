import React,{ PropTypes, Component } from 'react'

class Table extends Component {
  constructor(){
    super();
  }
  render(){
    console.log('table render',this.props.tableData)
    return(
      <div>
        <table>
          <tr>
            <th>Name</th>
          </tr>
          <tr>
            <td>{this.props.tableData.details}</td>
          </tr>
        </table>
      </div>
    )
  }
}

export default Table
