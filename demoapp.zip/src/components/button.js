import React,{ PropTypes, Component } from 'react'

class Button extends Component {
  render(){
    return (
      <input type="button" value="Add New List" onClick={this.props.onClick}/>
    )
  }
}

export default Button
