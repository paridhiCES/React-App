const initialState = {
  tableData : []
}
const table = (state=initialState, action) => {
  switch (action.type) {
    case 'ADD_ROW':
      return [
        ...state,
        {
          row: action.data
        }
      ]
      break;
    default:
        return state
  }
}

export default table
