const initialState = {
  details : ''
}
const details = (state=initialState, action) => {
  console.log(action);
  switch (action.type) {
    case 'ADD_DETAILS':
        return {
          ...state,
          details: action.data
        }
      break;
    default:
      return state
  }
}

export default details
