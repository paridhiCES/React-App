import { combineReducers } from 'redux'
import details from './details'
import table from './table'

const demoApp = combineReducers({
  details: details,
  table: table
})
export default demoApp;
