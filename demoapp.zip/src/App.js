import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Button from './components/button'
import Table from './containers/tableData'
import { browserHistory } from 'react-router'

class App extends Component {
  constructor(props){
    super(props);
    this.onClick = this.onClick.bind(this);
  }

  onClick(){
    console.log("Button Clicked")
    browserHistory.push('/form')
  }

  render() {
    return (
      <div className="App">
        <Button onClick={this.onClick}/>
        <Table />
      </div>
    );
  }
}

export default App;
