export function addDetails (data) {
  console.log('actions')
  return {
    type: 'ADD_DETAILS',
    data
  }
}
