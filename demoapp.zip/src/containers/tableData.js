import { connect } from 'react-redux'
import Table from '../components/table'
import { bindActionCreators } from 'redux'
import { addDetails } from '../actions'

const mapStateToProps = (state) => {
  return {
    tableData: state.details,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    actions: bindActionCreators(addDetails, dispatch)
  }
}

const TableData = connect(
  mapStateToProps,
  mapDispatchToProps
)(Table)
export default TableData
