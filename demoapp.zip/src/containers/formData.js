import { connect } from 'react-redux'
import AddForm from '../components/AddForm'
import { bindActionCreators } from 'redux'
import * as actions from '../actions'

const mapStateToProps = (state) => {
  return {
    details: state.details,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    actions: bindActionCreators(actions, dispatch)
  }
}

const FormDetails = connect(
  mapStateToProps,
  mapDispatchToProps
)(AddForm)
export default FormDetails
